// ==========================================================================
// PokéCRAFT PC Edition - Exportar jogo / Carregar jogo (arquivo .pokecraft)
//
// Exporta o jogo INTEIRO para um único arquivo e carrega esse arquivo de volta,
// inclusive pela tela inicial. Diferente dos slots (save_manager.js), isto
// também leva os mundos gerados, que o jogo guarda no IndexedDB
// ('poke-redstone' / store 'worlds'), além de tudo que está no localStorage.
//
// Formato do arquivo (JSON):
//   { format: 'pokecraft-game', version: 2, exportedAt, summary,
//     localStorage: { chave: texto, ... },
//     indexedDB:    { worlds: [ { key, value }, ... ] } }
//
// Também aceita os arquivos .sav antigos do gerenciador de slots e um save
// Classic cru ({ v: 1, ... }).
// ==========================================================================

(() => {
  // ---- textos da interface (mude aqui se quiser outro idioma) ------------
  const T = {
    exportLabel: '⬇ Exportar jogo',
    loadLabel: '📂 Carregar jogo',
    exported: (n) => `💾 Jogo exportado: ${n}`,
    nothing: '⚠️ Não há nenhum jogo salvo para exportar.',
    saveWarn: '⚠️ Não consegui salvar o estado atual; exportando o último save.',
    exportFail: '❌ Falha ao exportar o jogo.',
    loaded: '📂 Jogo carregado! Reiniciando...',
    loadFail: (why) => `❌ Não foi possível carregar: ${why}`,
    confirmReplace: (desc) =>
      'Carregar este arquivo vai SUBSTITUIR o progresso atual do jogo neste computador.\n\n' +
      (desc ? `Conteúdo do arquivo:\n${desc}\n\n` : '') +
      'Dica: use "Exportar jogo" antes se quiser guardar o progresso atual.\n\nContinuar?',
  };

  const FORMAT = 'pokecraft-game';
  const VERSION = 2;
  const FILE_EXT = '.pokecraft';
  const DB_NAME = 'poke-redstone';
  const STORE = 'worlds';
  // Só estas chaves entram no arquivo e só estas podem ser escritas ao carregar
  // (um arquivo de fora nunca consegue gravar chaves arbitrárias).
  const KEY_OK = /^(poke-|pokecraft[-_])/;
  // O progresso em si: é isto que um arquivo completo substitui.
  const PROGRESS_KEY = /^poke-redstone-(v1|worlds|w:.*)$/;

  // ---- serialização (o IndexedDB guarda objetos, o arquivo é JSON) -------
  const TYPED = ['Int8Array', 'Uint8Array', 'Uint8ClampedArray', 'Int16Array', 'Uint16Array',
    'Int32Array', 'Uint32Array', 'Float32Array', 'Float64Array'];

  function toB64(u8) {
    let s = '';
    for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    return btoa(s);
  }
  function fromB64(str) {
    const bin = atob(str), u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u;
  }
  function enc(v) {
    if (v === undefined) return { __pc: 'undef' };
    if (v === null || typeof v !== 'object') {
      if (typeof v === 'number' && !Number.isFinite(v)) return { __pc: 'num', v: String(v) };
      return v;
    }
    if (v instanceof ArrayBuffer) return { __pc: 'ab', d: toB64(new Uint8Array(v)) };
    if (ArrayBuffer.isView(v)) return { __pc: 'ta', t: v.constructor.name, d: toB64(new Uint8Array(v.buffer, v.byteOffset, v.byteLength)) };
    if (v instanceof Date) return { __pc: 'date', v: v.getTime() };
    if (v instanceof Map) return { __pc: 'map', v: [...v].map(([k, x]) => [enc(k), enc(x)]) };
    if (v instanceof Set) return { __pc: 'set', v: [...v].map(enc) };
    if (Array.isArray(v)) return v.map(enc);
    const o = {};
    for (const k of Object.keys(v)) o[k] = enc(v[k]);
    return o;
  }
  function dec(v) {
    if (v === null || typeof v !== 'object') return v;
    if (Array.isArray(v)) return v.map(dec);
    switch (v.__pc) {
      case 'undef': return undefined;
      case 'num': return Number(v.v);
      case 'ab': return fromB64(v.d).buffer;
      case 'ta': {
        if (!TYPED.includes(v.t)) throw new Error('tipo de dado desconhecido: ' + v.t);
        return new globalThis[v.t](fromB64(v.d).buffer);
      }
      case 'date': return new Date(v.v);
      case 'map': return new Map(v.v.map(([k, x]) => [dec(k), dec(x)]));
      case 'set': return new Set(v.v.map(dec));
    }
    const o = {};
    for (const k of Object.keys(v)) o[k] = dec(v[k]);
    return o;
  }

  // ---- IndexedDB (mesma abertura que o jogo usa em src/worlds.js) --------
  function openDB() {
    return new Promise((resolve) => {
      if (typeof indexedDB === 'undefined') return resolve(null);
      let req;
      try { req = indexedDB.open(DB_NAME, 1); } catch (e) { return resolve(null); }
      // mesma criação do jogo: sem isto, abrir um banco novo deixaria a store de fora
      req.onupgradeneeded = () => {
        try { if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE); } catch (e) { /* falha abaixo */ }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
      req.onblocked = () => resolve(null);
    });
  }
  // [{ key, value }] (value já codificado); null se a leitura falhar
  async function dumpWorlds() {
    const conn = await openDB();
    if (!conn) return [];
    return new Promise((resolve) => {
      try {
        const tx = conn.transaction(STORE, 'readonly');
        const st = tx.objectStore(STORE);
        const kq = st.getAllKeys(), vq = st.getAll();
        tx.oncomplete = () => {
          try { resolve(kq.result.map((key, i) => ({ key, value: enc(vq.result[i]) }))); }
          catch (e) { resolve(null); }
          conn.close();
        };
        tx.onerror = tx.onabort = () => { conn.close(); resolve(null); };
      } catch (e) { conn.close(); resolve(null); }
    });
  }
  async function countWorlds() {
    const conn = await openDB();
    if (!conn) return 0;
    return new Promise((resolve) => {
      try {
        const tx = conn.transaction(STORE, 'readonly');
        const q = tx.objectStore(STORE).count();
        tx.oncomplete = () => { conn.close(); resolve(q.result || 0); };
        tx.onerror = tx.onabort = () => { conn.close(); resolve(0); };
      } catch (e) { conn.close(); resolve(0); }
    });
  }
  // troca TODO o conteúdo da store pelos registros (uma transação: ou vai tudo ou nada)
  async function replaceWorlds(records) {
    const conn = await openDB();
    if (!conn) {
      if (records.length) throw new Error('o armazenamento de mundos (IndexedDB) não está disponível');
      return;
    }
    await new Promise((resolve, reject) => {
      try {
        const tx = conn.transaction(STORE, 'readwrite');
        const st = tx.objectStore(STORE);
        tx.oncomplete = () => { conn.close(); resolve(); };
        tx.onerror = tx.onabort = () => { conn.close(); reject(new Error('falha ao gravar os mundos: ' + (tx.error || ''))); };
        st.clear();
        for (const r of records) st.put(dec(r.value), r.key);
      } catch (e) { conn.close(); reject(e); }
    });
  }

  // ---- localStorage -------------------------------------------------------
  function collectLS() {
    const o = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && KEY_OK.test(k)) o[k] = localStorage.getItem(k);
    }
    return o;
  }
  function describe(ls, worldCount) {
    const parts = [];
    try {
      const c = ls['poke-redstone-v1'] ? JSON.parse(ls['poke-redstone-v1']) : null;
      if (c) {
        const lvl = c.P && c.P.level ? ` · nível ${c.P.level}` : '';
        const mins = c.playTime ? ` · ${Math.floor(c.playTime / 60)} min` : '';
        const mon = Array.isArray(c.party) ? ` · ${c.party.length} Pokémon` : '';
        parts.push(`• Kanto Clássico${lvl}${mins}${mon}`);
      }
    } catch (e) { /* ignora */ }
    try {
      const idx = ls['poke-redstone-worlds'] ? JSON.parse(ls['poke-redstone-worlds']) : null;
      const names = idx && Array.isArray(idx.worlds) ? idx.worlds.filter((w) => w && w.name).map((w) => w.name) : [];
      if (names.length) parts.push(`• Mundos: ${names.slice(0, 6).join(', ')}${names.length > 6 ? '…' : ''}`);
      else if (worldCount) parts.push(`• ${worldCount} mundo(s) gerado(s)`);
    } catch (e) { /* ignora */ }
    return parts.join('\n');
  }
  function stamp() {
    const d = new Date(), p = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}`;
  }

  // ---- aviso na tela (mesmo toast do gerenciador de slots) ---------------
  function toast(msg, ok = true) {
    let el = document.getElementById('emulator-toast');
    if (!el) { el = document.createElement('div'); el.id = 'emulator-toast'; document.body.appendChild(el); }
    el.textContent = msg;
    el.className = (ok ? 'toast-success' : 'toast-error') + ' show';
    clearTimeout(el._timer);
    el._timer = setTimeout(() => { el.className = el.className.replace('show', '').trim(); }, 3600);
  }
  const backToGame = () => { const c = document.getElementById('game'); if (c) c.focus(); };

  // ---- EXPORTAR -----------------------------------------------------------
  async function buildBundle() {
    const ls = collectLS();
    const worlds = await dumpWorlds();
    if (worlds === null) throw new Error('não consegui ler os mundos salvos');
    const hasClassic = !!ls['poke-redstone-v1'];
    const hasIndex = !!ls['poke-redstone-worlds'];
    if (!hasClassic && !hasIndex && !worlds.length) return null;
    return {
      format: FORMAT,
      version: VERSION,
      app: 'PokeCraft PC',
      exportedAt: new Date().toISOString(),
      summary: describe(ls, worlds.length),
      localStorage: ls,
      indexedDB: { worlds },
    };
  }

  async function exportGame() {
    try {
      // Só manda o jogo salvar se estiver jogando. Na tela inicial o "mundo" em
      // memória é um novo vazio: salvar ali poderia sobrescrever o save real.
      const rs = window.__rs, g = window.__pokeGame;
      const playing = rs && typeof rs.state === 'function' && rs.state() === 'play';
      if (playing && g && typeof g.save === 'function') {
        let r;
        try { r = await Promise.resolve(g.save()); } catch (e) { r = false; }
        if (r === false || (r && r.ok === false)) toast(T.saveWarn, false);
      }
      const bundle = await buildBundle();
      if (!bundle) { toast(T.nothing, false); return false; }
      const blob = new Blob([JSON.stringify(bundle)], { type: 'application/json' });
      const name = `PokeCraft_jogo_${stamp()}${FILE_EXT}`;
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 60000);
      toast(T.exported(name));
      return true;
    } catch (e) {
      console.error('[game_transfer] exportar', e);
      toast(T.exportFail, false);
      return false;
    } finally { backToGame(); }
  }

  // ---- CARREGAR -----------------------------------------------------------
  // Aceita o arquivo novo, o .sav de slot antigo e um save Classic cru.
  function parseFile(text) {
    let p;
    try { p = JSON.parse(text); } catch (e) { throw new Error('o arquivo não é um save válido do PokéCRAFT'); }
    if (!p || typeof p !== 'object') throw new Error('o arquivo não é um save válido do PokéCRAFT');

    if (p.format === FORMAT) {
      if (!(p.version >= 1 && p.version <= VERSION)) throw new Error('arquivo de uma versão mais nova do jogo');
      if (!p.localStorage || typeof p.localStorage !== 'object') throw new Error('arquivo incompleto');
      const worlds = p.indexedDB && Array.isArray(p.indexedDB.worlds) ? p.indexedDB.worlds : [];
      for (const w of worlds) if (!w || typeof w.key !== 'string') throw new Error('arquivo com mundos corrompidos');
      return { ls: p.localStorage, worlds, full: true };
    }
    if (p.storage && typeof p.storage === 'object') return { ls: p.storage, worlds: null, full: false };   // slot antigo
    if (p.v === 1 && p.world) return { ls: { 'poke-redstone-v1': text }, worlds: null, full: false };      // Classic cru
    throw new Error('formato de arquivo não reconhecido');
  }

  async function hasProgress() {
    const ls = collectLS();
    if (ls['poke-redstone-v1'] || ls['poke-redstone-worlds']) return true;
    return (await countWorlds()) > 0;
  }

  async function importGame(file) {
    try {
      if (!file) return false;
      const parsed = parseFile(await file.text());

      // só chaves do jogo, só texto
      const ls = {};
      for (const [k, v] of Object.entries(parsed.ls)) if (KEY_OK.test(k) && typeof v === 'string') ls[k] = v;
      const hasData = !!ls['poke-redstone-v1'] || !!ls['poke-redstone-worlds'] || (parsed.worlds && parsed.worlds.length);
      if (!hasData) throw new Error('o arquivo não contém nenhum jogo salvo');

      if (await hasProgress()) {
        const desc = describe(ls, parsed.worlds ? parsed.worlds.length : 0);
        if (!window.confirm(T.confirmReplace(desc))) { backToGame(); return false; }
      }

      // 1) localStorage, guardando o estado anterior para desfazer se algo falhar
      const before = collectLS();
      try {
        if (parsed.full) for (const k of Object.keys(before)) if (PROGRESS_KEY.test(k)) localStorage.removeItem(k);
        for (const [k, v] of Object.entries(ls)) localStorage.setItem(k, v);
      } catch (e) {
        for (const k of Object.keys(collectLS())) if (!(k in before)) localStorage.removeItem(k);
        for (const [k, v] of Object.entries(before)) { try { localStorage.setItem(k, v); } catch (e2) { /* melhor esforço */ } }
        throw new Error('sem espaço de armazenamento suficiente');
      }

      // 2) mundos gerados (IndexedDB, transação única); se falhar, volta o localStorage
      if (parsed.full) {
        try { await replaceWorlds(parsed.worlds); }
        catch (e) {
          for (const k of Object.keys(collectLS())) if (!(k in before)) localStorage.removeItem(k);
          for (const [k, v] of Object.entries(before)) { try { localStorage.setItem(k, v); } catch (e2) { /* melhor esforço */ } }
          throw e;
        }
      }

      toast(T.loaded);
      setTimeout(() => location.reload(), 700);
      return true;
    } catch (e) {
      console.error('[game_transfer] carregar', e);
      toast(T.loadFail(e && e.message ? e.message : 'erro desconhecido'), false);
      backToGame();
      return false;
    }
  }

  // ---- botão "Carregar jogo" na tela inicial -------------------------------
  const css = document.createElement('style');
  css.textContent = `
    #pc-title-load { position: fixed; z-index: 1000; display: none; transform: translate(-50%, -50%); margin: 0; }
    #pc-title-load.show { display: block; }
    #pc-title-load label {
      display: block; box-sizing: border-box; cursor: pointer; user-select: none; text-align: center; white-space: nowrap;
      padding: .45em 1.3em; font: 700 var(--pc-fs, 14px) ui-monospace, Menlo, monospace; letter-spacing: .03em;
      color: #e6e6e6; background: #3a3a3a; border: 2px solid #121212; border-top-color: #8a8a8a; border-left-color: #8a8a8a;
      box-shadow: 0 0 0 2px #000; text-shadow: 1px 1px 0 #1c1c1c;
    }
    #pc-title-load label:hover, #pc-title-load label:focus-within { background: #5a6aa8; color: #fff; }
    #pc-title-load input { position: absolute; width: 1px; height: 1px; opacity: 0; pointer-events: none; }
  `;
  document.head.appendChild(css);

  let titleBox = null;
  function ensureTitleBox() {
    if (titleBox) return titleBox;
    titleBox = document.createElement('div');
    titleBox.id = 'pc-title-load';
    titleBox.innerHTML = `<label title="Carregar um jogo exportado (${FILE_EXT})">${T.loadLabel}` +
      `<input type="file" data-pc-load-game accept="${FILE_EXT},.sav,.json"></label>`;
    document.body.appendChild(titleBox);
    return titleBox;
  }
  function updateTitleBox() {
    const canvas = document.getElementById('game');
    const rs = window.__rs;
    const onTitle = canvas && rs && typeof rs.state === 'function' && rs.state() === 'title' &&
      !(typeof rs.titleMenus === 'function' && rs.titleMenus()) && !window.__settingsModalOpen;
    const box = ensureTitleBox();
    if (!onTitle) { box.classList.remove('show'); return; }
    const r = canvas.getBoundingClientRect();
    // fica entre o logo e o "PRESS START" (coordenadas internas do canvas: 480x320)
    box.style.left = Math.round(r.left + r.width * (180 / 480)) + 'px';
    box.style.top = Math.round(r.top + r.height * (212 / 320)) + 'px';
    box.style.setProperty('--pc-fs', Math.max(11, Math.min(20, r.width / 46)).toFixed(1) + 'px');
    box.classList.add('show');
  }
  setInterval(updateTitleBox, 150);
  window.addEventListener('resize', updateTitleBox);

  // ---- ligação com os botões (delegada, funciona mesmo se o menu mudar) ----
  document.addEventListener('click', (e) => {
    const t = e.target.closest && e.target.closest('[data-pc-export-game]');
    if (t) { e.preventDefault(); e.stopPropagation(); exportGame(); }
  }, true);
  document.addEventListener('change', (e) => {
    const inp = e.target;
    if (inp && inp.matches && inp.matches('input[data-pc-load-game]')) {
      const f = inp.files && inp.files[0];
      inp.value = '';
      if (f) importGame(f);
    }
  });

  window.__pokeTransfer = { exportGame, importGame, _enc: enc, _dec: dec, _dump: dumpWorlds, _replace: replaceWorlds };
})();
